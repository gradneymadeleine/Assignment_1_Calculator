For all questions go first to 

    ../../Lab1-Lambda-Calculus/README.md