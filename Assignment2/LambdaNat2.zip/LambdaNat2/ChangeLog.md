# Changelog for CPPTypeChecker

## Unreleased changes
